# UCOApp
App to Sistema Interactivos subject

### Development

- [x] Log in.
- [x] Student Interface.
    - [x] Consultar notas.
    - [x] Consultar matrícula.
    - [ ] Consultar horarios.
    - [x] Información del grado.
- [x] Teacher interface.
    - [x] Campus Docente.
    - [x] Estudios Propios.
    - [x] Seguimiento Tesis y TFG.
- [x] Interface.
    - [x] Navigation Bar.
    - [x] ool Bar.
    - [x] pp Banner
